package com.study.planner
import android.app.*
import android.content.*

class AlarmReceiver : BroadcastReceiver() {
  override fun onReceive(c: Context, i: Intent) {
    val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    nm.createNotificationChannel(NotificationChannel("study", "Study reminders", NotificationManager.IMPORTANCE_HIGH))
    val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    val n = Notification.Builder(c, "study").setSmallIcon(android.R.drawable.ic_popup_reminder)
      .setContentTitle("Study Planner").setContentText(i.getStringExtra("m") ?: "Time to study")
      .setStyle(Notification.BigTextStyle().bigText(i.getStringExtra("m") ?: ""))
      .setContentIntent(open).setAutoCancel(true).build()
    nm.notify(System.currentTimeMillis().toInt(), n)
  }
}
