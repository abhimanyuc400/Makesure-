package com.study.planner
import android.Manifest
import android.app.*
import android.content.*
import android.os.*
import android.provider.Settings
import android.webkit.*
import org.json.JSONArray

class MainActivity : Activity() {
  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    val w = WebView(this)
    w.settings.javaScriptEnabled = true
    w.settings.domStorageEnabled = true
    w.addJavascriptInterface(Bridge(this), "Android")
    w.loadUrl("file:///android_asset/index.html")
    setContentView(w)
  }
}

class Bridge(val c: Context) {
  private val p = c.getSharedPreferences("s", 0)
  private fun pi(i: Int, m: String) = PendingIntent.getBroadcast(c, i,
    Intent(c, AlarmReceiver::class.java).putExtra("m", m), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

  @JavascriptInterface fun schedule(json: String) {
    val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    for (i in 0 until p.getInt("n", 0)) am.cancel(pi(i, ""))
    val a = JSONArray(json)
    for (i in 0 until a.length()) {
      val o = a.getJSONObject(i)
      val t = o.getLong("ts"); val x = pi(i, o.getString("msg"))
      if (am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, x)
      else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, x)
    }
    p.edit().putInt("n", a.length()).apply()
  }
  @JavascriptInterface fun getReel() = p.getBoolean("reel", false)
  @JavascriptInterface fun setReel(v: Boolean) { p.edit().putBoolean("reel", v).apply() }
  @JavascriptInterface fun openAccess() {
    c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
  }
}
