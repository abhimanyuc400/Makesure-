package com.study.planner
import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class ReelBlockService : AccessibilityService() {
  private var last = 0L
  override fun onAccessibilityEvent(e: AccessibilityEvent) {
    if (!getSharedPreferences("s", 0).getBoolean("reel", false)) return
    val root = rootInActiveWindow ?: return
    val ids = when (e.packageName?.toString()) {
      "com.instagram.android" -> listOf("com.instagram.android:id/clips_viewer_view_pager", "com.instagram.android:id/clips_viewer_container")
      "com.google.android.youtube" -> listOf("com.google.android.youtube:id/reel_recycler", "com.google.android.youtube:id/reel_player_page_container")
      else -> return
    }
    if (ids.any { root.findAccessibilityNodeInfosByViewId(it).isNotEmpty() } && System.currentTimeMillis() - last > 1500) {
      last = System.currentTimeMillis()
      performGlobalAction(GLOBAL_ACTION_BACK)
      Toast.makeText(this, "Reels blocked - go study!", Toast.LENGTH_SHORT).show()
    }
  }
  override fun onInterrupt() {}
}
