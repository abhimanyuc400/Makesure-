plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{namespace="com.study.planner";compileSdk=34
defaultConfig{applicationId="com.study.planner";minSdk=26;targetSdk=34;versionCode=1;versionName="1.0"}
compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
kotlinOptions{jvmTarget="17"}}
